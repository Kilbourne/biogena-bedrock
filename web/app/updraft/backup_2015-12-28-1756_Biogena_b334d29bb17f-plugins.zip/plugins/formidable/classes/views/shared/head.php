<?php
_deprecated_file( basename(__FILE__), '2.0', null, __( 'Use wp_enqueue_script and wp_enqueue_style.', 'formidable' ) );
