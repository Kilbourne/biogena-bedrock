<div class="frm_update_msg <?php echo esc_attr( $class ) ?>">
 This plugin version does not give you access to <?php echo $features ?>.<br/>
 <a href="http://formidablepro.com/pricing/" target="_blank">Compare</a> our plans or enter your license number <a href="<?php echo esc_url( admin_url('admin.php?page=formidable-settings') ) ?>">here</a>
</div>
