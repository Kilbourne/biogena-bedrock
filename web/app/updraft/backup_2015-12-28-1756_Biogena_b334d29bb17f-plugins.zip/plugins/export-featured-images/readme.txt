===Export Featured Images ===
Author: Damian Logghe
Contributors: timersys
Website: http://www.timersys.com
Tags: export images, export featured images, export featured, featured image, export, 
Stable tag: 1.0
Tested up to: 3.9.1
License: GPLv2 or later

Export Categories, Tags and Taxonomies

== Description ==

Simple and basic plugin that let you export Featured images from posts or custom post types into a Wordpress xml so you can import them in other sites using the Wordpress importer tool

== Installation ==

1. Go to Plugins > Add New
1. Click the Upload link
1. Click Browse and locate the `featured-images.x.x.zip` file
1. Click Install Now
1. After WordPress installs, click on the Activate Plugin link

You're done!

== Frequently Asked Questions ==

= Where do I find this great tool in my wp-admin? =

Just go to Tools-> Export Featured images

== Changelog ==

= 1.0 =
* Plugin released, woohoo!
