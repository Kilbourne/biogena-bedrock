### 1.0.0: 2015-04-03

* Plugin completely revamped
* Activation/deactivation hooks working properly (using WordPress native functions to activate/deactivate plugins