<footer>
 <div class="container">
   <div class="copyr">
    2015  - Valetudo S.r.l. / Divisione Biogena
    </div><div class="privacy"><a href="<?php $page_obj = get_page_by_title( 'Condizioni d\'Uso') ; echo get_page_link($page_obj -> ID) ; ?>" title="" class="ajax-popup-link" >Condizioni d'uso</a> - <a href="<?php $page_obj = get_page_by_title( 'Privacy') ; echo get_page_link($page_obj -> ID) ; ?>" title="" class="ajax-popup-link" >Politica di privacy</a> - <a href="<?php $page_obj = get_page_by_title( 'Cookies') ; echo get_page_link($page_obj -> ID) ; ?>" title="" class="ajax-popup-link">Cookies</a>
    </div><div class="contatti"><a href="<?php $page_obj = get_page_by_title( 'Contatti') ; echo get_page_link($page_obj -> ID) ; ?>" title="" class="ajax-popup-link">Contatti</a> - <a href="<?php $page_obj = get_page_by_title( 'Faq') ; echo get_page_link($page_obj -> ID) ; ?>" title="FAQ" class="ajax-popup-link" >FAQ</a> - <a href="<?php $page_obj = get_page_by_title( 'Area Riservata') ; echo get_page_link($page_obj -> ID) ; ?>" title="Area Riservata" class="ajax-popup-link" >Area Riservata</a> - <a href="<?php $page_obj = get_page_by_title( 'Lavora con Noi') ; echo get_page_link($page_obj -> ID) ; ?>" title="Lavora con noi" class="ajax-popup-link">Lavora con noi</a>
    </div><div class="social"><a href=""><span class='fb'></span></a><a href=""><span class='twt'></span></a><a href=""><span class='insta'></span></a><a href=""><span class='yt'></span></a> </div>
 </div>
</footer>

